import './App.css'

function App() {

  return (
    <main>
      Vite App
    </main>
  )
}

export default App
